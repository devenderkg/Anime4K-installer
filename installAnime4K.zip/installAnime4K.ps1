# Install Chocolatey package manager
Set-ExecutionPolicy Bypass -Scope Process -Force;
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072;
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'));

# Install MPV using Chocolatey
choco install mpv -y;

# Download and extract Anime4K GLSL files
$zipUrl = 'https://github.com/Tama47/Anime4K/releases/download/v4.0.1/GLSL_Windows_Low-end.zip';
$destinationPath = "$env:APPDATA\mpv";

# Create destination directory if it doesn't exist
if (-not (Test-Path -Path $destinationPath -PathType Container)) {
    New-Item -ItemType Directory -Path $destinationPath | Out-Null;
}

# Download zip file
Invoke-WebRequest -Uri $zipUrl -OutFile "$env:TEMP\Anime4K.zip";

# Extract contents to destination path
Add-Type -AssemblyName System.IO.Compression.FileSystem;
[System.IO.Compression.ZipFile]::ExtractToDirectory("$env:TEMP\Anime4K.zip", $destinationPath);

# Clean up temporary zip file
Remove-Item "$env:TEMP\Anime4K.zip" -Force;

# Display success message
Write-Host "Anime4K GLSL files have been successfully installed in $destinationPath.";

# Ask user to close PowerShell
Write-Host "Please close PowerShell to finish the installation."
